#ifndef GRAPH_H
#define GRAPH_H

#include <exception>
using namespace std;

int graph(int num, bool cont);
int graphBenchmark(int num, int n,bool cont);

#endif
